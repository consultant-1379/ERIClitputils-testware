#! /bin/bash
cd /home/lciadm100/run_python_tests/
py3pps=/home/lciadm100/tools/py-3pps-2.0;
pytar=py-3pps-2.0.tar.gz;
JENKINS_URL=https://fem32s11-eiffel004.eiffel.gic.ericsson.se:8443/jenkins;
if [[ ! -d $py3pps ]];
then 
  wget -nv ${JENKINS_URL}/userContent/${pytar};
  tar zxf $pytar -C $(dirname ${py3pps});
fi

litp_req=/home/lciadm100/tools/litp-requirements-py;
litp_req_tar=litp-requirements-py.tar.gz;
JENKINS_URL=https://fem32s11-eiffel004.eiffel.gic.ericsson.se:8443/jenkins;

if [[ -d $litp_req ]];
then
  echo "Removing previous litp-requirements-py dir from $litp_req and previous $litp_req_tar";
  line=$(grep -r host.gw.user.root.pass= /home/lciadm100/run_python_tests/host.properties);
  password=$(echo $line  | awk -F"=" '{print $2}');
  echo $password | sudo rm -rf $litp_req;
  echo $password | sudo rm -rf $litp_req_tar;
fi

wget -nv ${JENKINS_URL}/userContent/${litp_req_tar};
tar zxf $litp_req_tar -C $(dirname ${litp_req});

echo " " >> ~/.bashrc
export LITP_PY=/home/lciadm100/tools/litp-requirements-py/usr
export PYTHONPATH=$LITP_PY/lib/python2.6/site-packages:$LITP_PY/lib64/python2.6/site-packages:/home/lciadm100/tools/py-3pps-2.0/lib/python2.6/site-packages:/home/lciadm100/tools/py-3pps-2.0/lib64/python2.6/site-packages
export PATH=$LITP_PY/bin:/usr/java/jdk1.7.0_17/bin:/home/lciadm100/tools/maven-latest/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/home/lciadm100/bin
echo "export LITP_PY=/home/lciadm100/tools/litp-requirements-py/usr" >> ~/.bashrc
echo "export PATH=$LITP_PY/bin:/usr/java/jdk1.7.0_17/bin:/home/lciadm100/tools/maven-latest/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/home/lciadm100/bin" >> ~/.bashrc
source ~/.bashrc

python copy_module_tarballs.py
cmd=( $(find /home/lciadm100/run_python_tests/ | grep litp_generic_test.py | sed s/litp_generic_test.py//g) )
echo "export PYTHONPATH=$LITP_PY/lib/python2.6/site-packages:$LITP_PY/lib64/python2.6/site-packages:$cmd:/home/lciadm100/tools/py-3pps-2.0/lib/python2.6/site-packages:/home/lciadm100/tools/py-3pps-2.0/lib64/python2.6/site-packages" >> ~/.bashrc
source ~/.bashrc
echo "export LITP_CONN_DATA_FILE=/home/lciadm100/run_python_tests/host.properties" >> ~/.bashrc
source ~/.bashrc
mkdir -p /home/lciadm100/run_python_tests/testcases
exit 0
