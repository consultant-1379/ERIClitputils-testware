"""
Test
"""

import paramiko
import time
import socket
import StringIO
import os
#import test_constants
#import string
import subprocess
import sys
from distutils.version import StrictVersion

class NodeConnect():
    """
    Test
    """

    def __init__(self, ipaddr="", username="", password=""):
        """
        """
        self.ipv4 = ipaddr
        self.username = username
        self.password = password
        self.ipv6 = None
        self.hostname = None
        self.host = None
        self.port = 22
        self.ssh = None
        # timeout for establishing ssh connection
        self.timeout = 10
        self.retry = 0
        # stdout and stderr buffer size, modify if necessary
        self.out_bufsize = 4096
        self.err_bufsize = 4096
        # 60 seconds timeout for I/O channel operations
        self.session_timeout = 60
        # Timeout to wait for output after execution of a cmd
        self.execute_timeout = 0.25
        
    def __connect(self, username=None, password=None):
        """Connect to a node using paramiko.SSHCLient

        Args:
           username  (str): username to override
           password  (str): password to override
           ipv4     (bool): switch between ipv4 and ipv6

        Returns:
           bool

        Raises:
           BadHostKeyException, AuthenticationException, SSHException,
           socket.error
        """
        self.retry += 1

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.host = self.ipv4
        username = self.username
        password = self.password
        try:
            ssh.connect(self.host,
                        port=self.port,
                        username=username,
                        password=password,
                        timeout=self.timeout)
            self.ssh = ssh
            self.retry = 0
            return True
        except paramiko.BadHostKeyException, except_err:
            self.__disconnect()
            raise
        except paramiko.AuthenticationException, except_err:
            self.__disconnect()
            raise
        except paramiko.SSHException or socket.error, except_err:
            if (self.retry < 2):
                time.sleep(5)
                self.__disconnect()
                return self.__connect(username, password)
            else:
                self.__disconnect()
                raise
        except Exception as except_err:
            print "Error connecting to node on {0}: {1}".\
                format(self.host, str(except_err))

            raise

    def __disconnect(self):
        """Close the paramiko.SSHClient
        """
        if self.ssh:
            try:
                self.ssh.close()
                self.ssh = None
            except Exception as except_err:
                print "Error disconnecting: {1}".\
                    format(str(except_err))
                self.ssh = None
        else:
            self.ssh = None

    def run_command(self, cmd, username=None, password=None, logs=True):
        """Run command on node
           stdout, stderr, rc (list, list, integer)
        """

        if logs:
            print "[{0}@{1}]# {2}".format(self.username,
                                              self.ipv4, cmd)

        stdout, stderr, exit_code = self.execute(
            cmd, username, password, logs=logs)

        return stdout, stderr, exit_code

    def execute(self, cmd, username=None, password=None, logs=True):
        """
        Test
        """
        username = self.username
        password = self.password
        if not self.ssh:
            self.__connect(username, password)
        if self.ssh:
            channel = self.ssh.get_transport().open_session()
            channel.settimeout(self.session_timeout)
            try:
                channel.exec_command(cmd)

                contents = StringIO.StringIO()
                errors = StringIO.StringIO()

                timed_out = False

                returnc = channel.recv_exit_status()

                while (True):

                    if channel.recv_ready():
                        data = channel.recv(self.out_bufsize)
                        while data:
                            contents.write(data)
                            data = channel.recv(self.out_bufsize)

                        break
                    if channel.recv_stderr_ready():
                        error = channel.recv_stderr(self.err_bufsize)
                        while error:
                            errors.write(error)
                            error = channel.recv_stderr(self.err_bufsize)

                        break

                    # After timeout we do one more loop to check
                    # if output buffers are ready and then we exit
                    if timed_out:
                        break

                    if not timed_out:
                        time.sleep(self.execute_timeout)
                        timed_out = True

            except socket.timeout, except_err:
                print 'Socket timeout error: {0}'.format(except_err)
                raise
            finally:
                if channel:
                    channel.close()

            if logs:
                print contents.getvalue()
                print errors.getvalue()
                print returnc

            out = self.__process_results(contents.getvalue())
            err = self.__process_results(errors.getvalue())

            self.__disconnect()

        return out, err, returnc

    def __process_results(self, result):
        """
        Test
        """
        processed = []
        for item in result.split('\n'):
            if item.strip():
                processed.append(item.strip())
        return processed

    def run_command_local(self, cmd, logs=True):
        """
        """
        if logs:
            print "[local]# {0}".format(cmd)

        child = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, shell=True)

        result = child.communicate()

        if logs:
            print result[0]
            print result[1]
            print child.returncode

        exit_code = child.returncode
        stdout = result[0].splitlines()
        stderr = result[1].splitlines()

        return stdout, stderr, exit_code

    def copy_file(self, local_filepath, remote_filepath):
        """
        Copy a file to the node using paramiko.SFTP
        """
        if not self.ssh:
            self.__connect()

        if self.ssh:

            try:
                sftp_session = self.ssh.open_sftp()
                sftp_session.put(local_filepath, remote_filepath)
            except IOError, except_err:
                raise
            finally:
                self.__disconnect()


def get_module_nexus(module_name, copy_dir_slave):
    """
    code to get a module downloaded to nexus
    """

    run = NodeConnect("", "", "")
    print ""
    print "----------------------------------------------"
    print "Copy of %s" % module_name
    print "----------------------------------------------"
    print ""
    DROP_PAGE = '"https://arm1s11-eiffel004.eiffel.gic.ericsson.se:8443/nexus/content/groups/public/com/ericsson/nms/litp/taf/%s/"  | grep "href" | grep -vE "SNAPSHOT|maven" | grep "%s"' % (module_name, module_name)
    WGET="wget -q --no-check-certificate -O -"
    cmd = "%s %s" % (WGET, DROP_PAGE)
    stdout, stderr, exit_code = run.run_command_local(cmd, logs=False)
    #if stdout == [] or stderr != [] or exit_code != 0:
    if stdout == []:
	print "ERROR getting ISO"
	exit(1)

    #wget -q --no-check-certificate -O - https://cifwk-oss.lmera.ericsson.se/LITP/2.1.5/media/ | grep hub

    newlist = []
    for line in stdout:
        thisone = line.replace('https://arm1s11-eiffel004.eiffel.gic.ericsson.se:8443/nexus/content/groups/public/com/ericsson/nms/litp/taf/%s/' % module_name, '')
        thisone = thisone.replace('<a href=\"', '')
        thisone = thisone.replace('<td>', '')
        thisone = thisone.replace('</td>', '')
        listone = thisone.replace('/</a>', '').replace(" ", "").split('/">')
        newlist.append(listone[1])


    sorted_versions = sorted(newlist, cmp=lambda x, y: StrictVersion(x).__cmp__(y))

    #for line in sorted_versions:
    #    print line
    ISONAME = "%s-%s.tar.gz" % (module_name, sorted_versions[-1])

    REMOTE_TARGET = "%s/" % copy_dir_slave

    cmd = "rm -rf %s/%s" % (REMOTE_TARGET, ISONAME)
    stdout, stderr, exit_code = run.run_command_local(cmd)
    if stderr != [] or exit_code != 0:
	print "ERROR Checking if ISO on node"
	exit(1)

    GETISO = '"https://arm1s11-eiffel004.eiffel.gic.ericsson.se:8443/nexus/content/groups/public/com/ericsson/nms/litp/taf/%s/%s/%s"' % (module_name, sorted_versions[-1], ISONAME)

    cmd = "%s %s -O %s/%s" % (WGET, GETISO, REMOTE_TARGET, ISONAME)
    stdout, stderr, exit_code = run.run_command_local(cmd)
    #if stdout == [] or stderr != [] or exit_code != 0:
    #if stdout == []:
    #    print "ERROR getting ISO"
    #    exit(1)

    time.sleep(1)
    cmd = "ls %s | grep %s" % (REMOTE_TARGET, ISONAME)
    stdout, stderr, exit_code = run.run_command_local(cmd)
    if stderr != []:
	print "ERROR Checking if ISO on node"
	exit(1)

    if ISONAME not in stdout:
	print "ISO not copied to node correctly"
	exit(1)

    cmd = "tar -C %s -zxvf %s/%s" % (REMOTE_TARGET, REMOTE_TARGET, ISONAME)
    stdout, stderr, exit_code = run.run_command_local(cmd)
    if stderr != [] or exit_code != 0:
	print "ERROR Checking if ISO on node"
	exit(1)

    cmd = "rm -rf %s/%s" % (REMOTE_TARGET, ISONAME)
    stdout, stderr, exit_code = run.run_command_local(cmd)
    if stderr != [] or exit_code != 0:
	print "ERROR Checking if ISO on node"
	exit(1)
    

# Disable output buffering to receive the output instantly
sys.stdout = os.fdopen(sys.stdout.fileno(), "w", 0)
sys.stderr = os.fdopen(sys.stderr.fileno(), "w", 0)


run = NodeConnect("", "", "")
print ""
print "###################################################"
print "START OF COPY OF ALL FILES FROM NEXUS"
print "###################################################"
print ""
TESTDIR = "/home/lciadm100/run_python_tests/utilsdir"
cmd = "rm -rf %s" % TESTDIR
run.run_command_local(cmd)
cmd = "mkdir %s" % TESTDIR
run.run_command_local(cmd)
get_module_nexus("ERIClitputils-testware", TESTDIR)

print ""
print "###################################################"
print "END OF COPY OF ALL FILES FROM NEXUS"
print "###################################################"
print ""

exit(0)
